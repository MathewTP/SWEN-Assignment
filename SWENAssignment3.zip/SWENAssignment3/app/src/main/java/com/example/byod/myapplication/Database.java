package com.example.byod.myapplication;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.byod.myapplication.test.DatabaseHelper;

public class Database extends AppCompatActivity {

    DatabaseHelper myDB;

    EditText editName, editDuty, editRoutine;
    Button btnAdd, btnViewAll, btnDeleteOneRow;
    EditText deleteID;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);
        myDB = new DatabaseHelper(Database.this);

        editName = (EditText)findViewById(R.id.editName);
        editDuty = (EditText)findViewById(R.id.editDuty);
        editRoutine = (EditText)findViewById(R.id.editRoutine);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        btnViewAll = (Button) findViewById(R.id.btnView);
        btnDeleteOneRow = (Button) findViewById(R.id.btnDeleteOneRow);
        deleteID = (EditText) findViewById(R.id.deleteID);
    }

    public void addData(View v)
    {
        if ((editName.getText().length() == 0) || (editDuty.getText().length() == 0) || (editRoutine.getText().length() == 0))
        {
            Toast.makeText(getApplicationContext(), "Error: some fields have missing info", Toast.LENGTH_LONG).show();
        }
        else
        {
            boolean isInserted = myDB.insertData
                    (editName.getText().toString(),
                            editDuty.getText().toString(),
                            editRoutine.getText().toString());

            if (isInserted) {
                Toast.makeText(getApplicationContext(), "Info is added.",
                        Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(getApplicationContext(), "Info is not added.",
                        Toast.LENGTH_SHORT).show();
            }
        }
        editName.setText("");
        editDuty.setText("");
        editRoutine.setText("");
    }

    public void viewData(View v)
    {
        Cursor results =  myDB.getAllData();
        if (results.getCount()==0) {
            Toast.makeText(getApplicationContext(), "Error: no data found!",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        else {
            StringBuffer buffer = new StringBuffer();
            while (results.moveToNext()) {
                buffer.append("Id: " +
                        results.getString(0) + "\n");
                buffer.append("Name: " +
                        results.getString(1)+ "\n");
                buffer.append("Duty: " +
                        results.getString(2)+ "\n");
                buffer.append("Routine: " +
                        results.getString(3)+ "\n\n\n");
            }
            Toast.makeText(getApplicationContext(), "Staff data is: \n" + buffer.toString(),
                    Toast.LENGTH_SHORT).show();
        }
    }
    public void deleteOneData(View v)
    {
        String id = deleteID.getText().toString();
        if (!id.equals("")) {
            myDB.deleteData(id);
        }
        deleteID.setText("");
    }


}
