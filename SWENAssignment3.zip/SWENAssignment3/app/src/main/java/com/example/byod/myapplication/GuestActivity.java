package com.example.byod.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class GuestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest);
    }

    public void clickBook(View v)
    {
        Toast.makeText(getApplicationContext(),"Your have successfully booked the hotel.",Toast.LENGTH_LONG).show();

    }
}
