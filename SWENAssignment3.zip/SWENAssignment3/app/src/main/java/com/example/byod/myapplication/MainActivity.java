package com.example.byod.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void GuestReservation(View view)
    {
      Intent Guestintent = new Intent(this, GuestActivity.class);
      startActivity(Guestintent);
    }

    public void StaffSystem(View view)
    {
      Intent Staffintent = new Intent(this, StaffActivity.class);
      startActivity(Staffintent);
    }

}
