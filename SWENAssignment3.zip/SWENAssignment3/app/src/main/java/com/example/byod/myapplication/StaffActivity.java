package com.example.byod.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class StaffActivity extends AppCompatActivity {

    private EditText username;
    private EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff);

        username = (EditText) findViewById(R.id.editText);
        password = (EditText) findViewById(R.id.editText2);

    }

    public void clickData(View v)
    {
        if ((username.getText().length() == 0) || (password.getText().length() == 0))
        {
            Toast.makeText(getApplicationContext(), "Error: You did not login properly.", Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(getApplicationContext(), "You have login database successfully.", Toast.LENGTH_LONG).show();

            Intent Dataintent = new Intent(this, Database.class);
            startActivity(Dataintent);

        }

    }



}
